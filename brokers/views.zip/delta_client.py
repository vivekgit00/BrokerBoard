import websocket
import json
import threading
from asgiref.sync import async_to_sync
from channels.layers import get_channel_layer


def subscribe_and_forward(symbols, channel_name):
    def on_message(ws, message):
        data = json.loads(message)
        print("Received from Delta:", data)

        # Forward to frontend via your Django channel
        channel_layer = get_channel_layer()
        print("delta_clien", channel_layer)
        async_to_sync(channel_layer.send)(channel_name, {
            "type": "send_ltp",
            "text": json.dumps(data)
        })

    def on_open(ws):

        print("Connected to Delta")
        payload = {
            "type": "subscribe",
            "payload": {
                "channels": [
                    {
                        "name": "candlestick_1m",
                        "symbols": symbols
                    }
                ]
            }
        }
        ws.send(json.dumps(payload))

    ws = websocket.WebSocketApp(
        "wss://socket.india.delta.exchange",
        on_open=on_open,
        on_message=on_message
    )
    ws.run_forever()
